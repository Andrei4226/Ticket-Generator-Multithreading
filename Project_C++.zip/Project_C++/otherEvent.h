#pragma once
#include<iostream>
#include "event.h"

using namespace std;
class otherEvent
{
public:
	virtual void print_temp() = 0;
};
